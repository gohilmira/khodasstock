
<div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

	<h4>A PHP Error was encountered</h4>

	<p>Severity: Notice</p>
	<p>Message:  Undefined index: Remark2</p>
	<p>Filename: controllers/Transaction_controller.php</p>
	<p>Line Number: 1076</p>


	<p>Backtrace:</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\application\controllers\Transaction_controller.php<br />
		Line: 1076<br />
		Function: _error_handler			</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\index.php<br />
		Line: 315<br />
		Function: require_once			</p>




</div>
<div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

	<h4>A PHP Error was encountered</h4>

	<p>Severity: Notice</p>
	<p>Message:  Undefined index: Grand_Total2</p>
	<p>Filename: controllers/Transaction_controller.php</p>
	<p>Line Number: 1077</p>


	<p>Backtrace:</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\application\controllers\Transaction_controller.php<br />
		Line: 1077<br />
		Function: _error_handler			</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\index.php<br />
		Line: 315<br />
		Function: require_once			</p>




</div>
<div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

	<h4>A PHP Error was encountered</h4>

	<p>Severity: Notice</p>
	<p>Message:  Undefined index: Amount_Less2</p>
	<p>Filename: controllers/Transaction_controller.php</p>
	<p>Line Number: 1079</p>


	<p>Backtrace:</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\application\controllers\Transaction_controller.php<br />
		Line: 1079<br />
		Function: _error_handler			</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\index.php<br />
		Line: 315<br />
		Function: require_once			</p>




</div>
<div style="border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;">

	<h4>A PHP Error was encountered</h4>

	<p>Severity: Notice</p>
	<p>Message:  Undefined index: Haste_Gstin</p>
	<p>Filename: controllers/Transaction_controller.php</p>
	<p>Line Number: 1080</p>


	<p>Backtrace:</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\application\controllers\Transaction_controller.php<br />
		Line: 1080<br />
		Function: _error_handler			</p>






	<p style="margin-left:10px">
		File: E:\xampp\htdocs\kodas\NEW\index.php<br />
		Line: 315<br />
		Function: require_once			</p>




</div>Array
(
[Finish_Purchase_Id] => 1
[Comapny_Id] => 1
[Type] => Finish Purchase
[Voucher] => 1
[Ord_Ref] => 1
[Lr_No_Awb] => 1
[Party_Id] => 72
[State_Id] => 12
[Bill_No] => 1
[CompanyID] => 1
[companyname] => BHARAT CREATION PRIVATE LIMITED
[AddressCompany] => G-2365/66 MILLENIUM TEX. MARKET
[CompanyPanNo] => AADCB9381M
[CompanyCinNo] => U17120GJ2009PTC058979
[CompanyGstInUin] => 24AADCB9381M1Z9
[Ledger_Id] => 72
[ledgername] => FULCRUM FABRICS
[ledgeraddress] => D-29/1-B, ROAD NO.16, HOJIWALA IND.
[LAddressLine2] =>
[partygstin] => 18AAUCS9084K1ZF
[LPanNo] =>
[LDistance] =>
[TransportID] => 1
[TransportName] => A TO Z CARGO SERVICEq
[Transport_Id] => 1
[Finish_Date] => 03/07/2019
[Gst_Type_Id] => 4
[Haste_Id] => 59
[Brocker_Id] => 57
[Dhara] => 20
[Grace] => 30
[Station_Id] => 21
[Screen_Series] => 3
[Party_Gstin] => 24AWVPA1981H1ZD
[Obtain_By] => m patel
[Remark_Id] => 2
[Only_X] => 0
[E_Way_Bill_No] => 1
[Net_Amt] =>
[Lr_No] => 1
[Lr_Date] => 03/07/2019
[Lr_Rec_Date] => 03/07/2019
[Weight] => 200
[Height] => 400
[Cgst] => 2.5
[Cgst_Amt] => 15
[Taxable_Value] => 600
[Bill_Amt] =>
[Net_After_Tds] =>
[Paid_Date] =>
[Discount] =>
[Pack_Folt] =>
[Rd] =>
[Sweets] =>
[Oth_Bc] =>
[Add_Amt] =>
[Tds_Amt] =>
[Gr] =>
[Rec_Sale_Vno] =>
[Paid_Amt] =>
[Rec_Sale_Pcs] =>
[Rec_Sale_Mts] =>
[Sgst] => 2.5
[Sgst_Amt] => 15
[Case_No] => 1
[Amount_Less] => 60
[Discount_Less2] => 20
[StationID] => 21
[StationName] => SURAT
[ScreenRegisterID] => 3
[ItemDCut] => 50
[RemarkID] => 2
[Remark] => AADAT+KATAI
[StateName] => Gujarat
[StateCode] => 24
[HasteGstIn] => 1
[Total_Pcs] => 30
[Total_Mts] => 210
[Grand_Total] => 600
[Remark1] => 2
[Grand_Total1] => 600
[Discount_Less1] => 10
)
